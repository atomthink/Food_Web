package com.zosh.service;

import com.zosh.model.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderIem (OrderItem orderItem);

}
