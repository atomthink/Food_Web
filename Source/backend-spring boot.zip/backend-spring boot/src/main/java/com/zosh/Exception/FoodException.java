package com.zosh.Exception;

public class FoodException extends Exception {

	public FoodException(String message) {
		super(message);

	}

}
